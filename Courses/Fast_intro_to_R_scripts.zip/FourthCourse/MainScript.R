# install.packages("PolynomF")
# install.packages("plot3D")

library(tidyverse)
library(PolynomF)
library(plot3D)

?poly_calc


p = poly_calc(0:5)
plot(p, col = 'blue')


p = poly_calc(0:5, exp(0:5))
plot(p, col = 'blue')
curve(exp, add = TRUE, col = "red")


# -------------------
# Faulhaber's formula

nbr = 100
n = c(1:nbr)

q = 3
Nq = n^q

fr = data.frame(n, Nq)
fr$cumul = cumsum(fr$Nq)

View(fr)

p = poly_calc(1:(q+2), fr$cumul[1:(q+2)])
p
plot(p)

fr$check = p(fr$n)

all(fr$check == fr$cumul)
all.equal(fr$cumul, p(fr$n), tolerance = 1e-2)


N = 11
qvals = seq(0, 1, length.out = N+1)
cols = colorRampPalette(c("blue", "red"))(length(qvals))


Faulhaber = list()

plot.new()
plot(0:1, 0:1, type="n")
for (q in 0:N) {
  print(q)
  Nq = n^q
  fr = data.frame(n, Nq)
  fr$cumul = cumsum(fr$Nq)
  p = poly_calc(1:(q+2), fr$cumul[1:(q+2)])
  Faulhaber = append(Faulhaber, p)
  print(p)
  print(p * (q+1)) # To have better coefficients.
  curve(p, from=0, to=1, xlab=q, n = 501, col = cols[q], add=TRUE)
  print(all.equal(fr$cumul, p(fr$n), tolerance = 1e-2))
  cat("\n") # print an empty line
}

# Bernoulli numbers

Faulhaber

coefficients(Faulhaber[1])
coefficients(Faulhaber[1])[1]
coefficients(Faulhaber[1])[2]

Bernoulli = data.frame(q = c(0:N))
for (q in 0:N) {
  Bernoulli$num[q+1] = coefficients(Faulhaber[q+1])[1+1]
}
View(Bernoulli)

plot(x = Bernoulli$q, y=Bernoulli$num)


# -------------------------------
# Linear models (several variables)

UniMean = Vectorize(function(a, b) mean(runif(100, min = a, max = b)))

M = c(1:100)
df = data.frame(M)

df$mean = UniMean(a = -10, b = M)
View(df)
plot(df)

?lm
model = lm(mean~M, data = df)
View(model)

q = ggplot(df, aes(x = M, y = mean)) +
  geom_point(shape=1, show.legend=FALSE) +
  geom_smooth(method="lm", se=TRUE, show.legend=FALSE)
q

summary(model)$r.squared
summary(model)$adj.r.squared

# --------

m = c(-1:-100)
M = c(1:100)
df = expand.grid(m = m, M = M)
df$mean = UniMean(a=df$m, b = df$M)
View(df)

model2 = lm(mean ~ m + M, data=df)
View(model2)
summary(model2)$r.squared
summary(model2)$adj.r.squared

scatter3D(x=df$m, y=df$M, z=df$mean, bty = "b2")

# --------
UniVar = Vectorize(function(a, b) var(runif(100, min = a, max = b)))
df$Var = UniVar(a=df$m, b = df$M)
View(df)

model3 = lm(Var ~ m + M, data=df)
View(model3)
summary(model3)$r.squared
summary(model3)$adj.r.squared

scatter3D(x=df$m, y=df$M, z=df$Var, bty = "b2")

training_set = df[df$m >= -5 & df$M <= 5, ]
# training_set = sample(nrow(df), nrow(df)/20)
training_set = df[training_set,]
dim(training_set)
model4 = lm(Var ~ m + M, data=training_set)
View(model4)
summary(model2)$r.squared
summary(model2)$adj.r.squared

b = coef(model4)
b

f <- Vectorize(function(x1, x2) {
  unname(b[1] + b["m"] * x1 + b["M"] * x2)
})
sse = sum((f(df$m, df$M) - df$Var)^2)
ssr = sum((f(df$m, df$M) - mean(df$Var))^2)
ssr / (sse + ssr)


# --------------
# Polynomial models

make_poly <- function(coef) {
  Vectorize(function(x) {
    sum(coef * x^(seq_along(coef) - 1))
  })
}

noisified_data <- function(f, x) {
  f(x) + 0.75*rnorm(length(x))
}

D = 5
# alpha = rnorm(D+1)
alpha = c(0.152866375, 1.257512796, -0.144738591, 0.339900781, 0.143917067, 0.002062239)

p = make_poly(alpha)
p(5)
p(0:4)

p(0) == alpha[1]   # Sanity check
p(1) == sum(alpha) # Sanity check

noisified_data(p, 0:10)

nbr = 10
X = rnorm(nbr)
Y = noisified_data(p, X)
plot(x = X, y = Y)

model = lm(Y ~ X)
summary(model)$r.squared

model = lm(Y ~ poly(X, 5))
summary(model)$r.squared

model = lm(Y ~ poly(X, 9))
summary(model)$r.squared

model = lm(Y ~ poly(X, 5, raw=TRUE))
coef(model)


d_max = nbr - 1
qvals = seq(0, 1, length.out = d_max+1)
cols = colorRampPalette(c("blue", "red"))(length(qvals))
poly_estimate = data.frame(d = 1:d_max)
plot(x = X, y = Y)
for (d in 1:d_max) {
  print(d)
  model = lm(Y ~ poly(X, d))
  poly_estimate$Rsquared[d] = summary(model)$r.squared
  
  estim_p = Vectorize(function(x){predict(model, newdata = data.frame(X = x))})
  curve(estim_p, from=min(X), to=max(X), xlab=d, n = 501, col = cols[d], add=TRUE)
}
View(poly_estimate)
plot(x = poly_estimate)

View(model)

# ------------
# Fitting versus predicting

nbr = 100
X = runif(nbr, -2.5, 2.5)
X = sort(X)
Y = noisified_data(p, X)
plot(x = X, y = Y)


training_set = data.frame(X = X[2 * 1:(nbr/2)], Y = Y[2 * 1:(nbr/2)])
validating_set = data.frame(X = X[-1 + 2 * 1:(nbr/2)], Y = Y[-1 + 2 * 1:(nbr/2)])
dim(training_set)
dim(validating_set)

d_max = 15 #nbr/2 - 1
poly_estimate = data.frame(d = 1:d_max)
for (d in 1:d_max) {
  print(d)
  model = lm(Y ~ poly(X, d), data = training_set)
  if (d == D) {
    plot(x = X, y = Y)
    estim_p = Vectorize(function(x){predict(model, newdata = data.frame(X = x))})
    curve(estim_p, from=min(X), to=max(X), xlab=d, n = 501, col = 'red', add=TRUE)
    curve(p, from=min(X), to=max(X), xlab=d, n = 501, col = 'blue', add=TRUE)
    }
  
  poly_estimate$Rsquared_training[d] = summary(model)$r.squared
  poly_estimate$aic[d] = AIC(model)
  poly_estimate$bic[d] = BIC(model)
  
  estim_p = Vectorize(function(x){predict(model, newdata = data.frame(X = x))})
  sse = sum((estim_p(validating_set$X) - validating_set$Y)^2)
  ssr = sum((estim_p(validating_set$X) - mean(validating_set$Y))^2)
  poly_estimate$Rsquared_validating[d] = ssr/(sse+ssr)
}
View(poly_estimate)

plot(x = poly_estimate$d, y = poly_estimate$Rsquared_training, type="l", col="blue")
points(x = poly_estimate$d, y = poly_estimate$Rsquared_training, col="blue")
points(x = poly_estimate$d, y = poly_estimate$Rsquared_validating, col="red")
lines(x = poly_estimate$d, y = poly_estimate$Rsquared_validating, col="red")

plot(x = poly_estimate$d, y = poly_estimate$aic, type="l", col="purple")
points(x = poly_estimate$d, y = poly_estimate$aic, col="purple")
points(x = poly_estimate$d, y = poly_estimate$bic, col="green")
lines(x = poly_estimate$d, y = poly_estimate$bic, col="green")



# ----------
# A model of degree 5 without degree 1

model = lm(Y ~ X^2 + X^3 + X^4 + X^5)

model = lm(Y ~ cos(X) + sin(X))

model = lm(Y^2 / X ~ cos(X))

d = 5
model = lm(Y ~ X^2 + I(X^d))


model = lm(Y ~ X^2 + X^3 + X^4 + X^5, data = training_set)
View(model)
AIC(model)
BIC(model)

estim_p = Vectorize(function(x){predict(model, newdata = data.frame(X = x))})
sse = sum((estim_p(validating_set$X) - validating_set$Y)^2)
ssr = sum((estim_p(validating_set$X) - mean(validating_set$Y))^2)
ssr/(sse+ssr)


# ---------
# Log-scales

nbr = 100
X = runif(nbr, 5, 10)
Y = noisified_data(p, X)
plot(x = log(X), y = log(Y))

model = lm(log(Y) ~ log(X))
summary(model)$r.squared
coef(model)


X = runif(nbr, 100, 150)
Y = noisified_data(p, X)
plot(x = log(X), y = log(Y))

model = lm(log(Y) ~ log(X))
summary(model)$r.squared
coef(model)

