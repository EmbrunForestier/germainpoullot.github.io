# install.packages("tidyverse")
# install.packages("PolynomF")
# install.packages("plot3D")

library(tidyverse)
library(PolynomF)
library(plot3D)

qvals = seq(0, 1, length.out = N+1)
cols = colorRampPalette(c("blue", "red"))(length(qvals))

UniMean = Vectorize(function(a, b) mean(runif(100, min = a, max = b)))
UniVar = Vectorize(function(a, b) var(runif(100, min = a, max = b)))

make_poly <- function(coef) {
  Vectorize(function(x) {
    sum(coef * x^(seq_along(coef) - 1))
  })
}

noisified_data <- function(f, x) {
  f(x) + 0.75*rnorm(length(x))
}

D = 5
# alpha = rnorm(D+1)
alpha = c(0.152866375, 1.257512796, -0.144738591, 0.339900781, 0.143917067, 0.002062239)

p = make_poly(alpha)