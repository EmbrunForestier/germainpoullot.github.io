#setwd("/home/jan/Downloads/R_exam/R_exam")

source("Exam_data.R")

sanity_check()

#Exercise 0
sample(1:6, 2, replace = TRUE)
# 1, 2
#~ Good

#Exercise 1
#1)
length(primes) + 1 #+1 because number two is missing from primes
#~ Good

#2)
P = data.frame(
  n = 2:669,
  p_n = primes[(2:669) - 1]
)
#~ Good

#3)
P$scaled_p_n = (P$p_n/log(P$n))
#~ Good

#4)
model = lm(scaled_p_n ~ n, P)
coef(model)
summary(model)$r.squared
#~ Good

#5)
last_digit = primes %% 10
sum(last_digit == 1) #163
sum(last_digit == 3) #172
sum(last_digit == 7) #169
sum(last_digit == 9) #163
#~ Good




#Exercise 2
#1
help(rcauchy)
#density function: dcauchy(x, location = 0, scale = 1, log = FALSE)
#probability distrubution: pcauchy(q, location = 0, scale = 1, lower.tail = TRUE, log.p = FALSE)
#quantiles: qcauchy(p, location = 0, scale = 1, lower.tail = TRUE, log.p = FALSE)
#~ Good

#2
C = data.frame(
  N = 1:1000
)

for (i in 1:nrow(C)){
  c = rcauchy(i)
  C$Mean[i] = mean(c)
  C$Standart_Deviation[i] = sd(c)
}
#~ Good

#3
plot(C$N,C$Mean)
plot(C$N,C$Standart_Deviation)
#since the cauchy distribution doesnt have an expectation it makes sense that there are strong outliers even for large values of n 
#~ Good

#4
colors = ifelse(abs(C$Mean) > 10, "red", "black")
plot(C$N, C$Standart_Deviation,
     col = colors)
#it seems than when the expectation is high, the standart deviation is also high as mostly the outliers (the points far away from zero) get colored red
#~ Good: (math-ish question) Is it possible to have a very large sampled mean and a very small sampled variance (and conversely)?

#5
inverse_cauchy = 1/rcauchy(1000)
ks.test(inverse_cauchy, "pcauchy",
        location = 0, scale = 1)
#running this test we get a p-value close to 1 (i got around 0.8) meaning that sample gave us no good reason to reject the hypothesis
#~ Good: Running this test several times can give a very low p-value (I got 0.206): explain.