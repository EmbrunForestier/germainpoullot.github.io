#R-Exam Statistik SoSe 2026
#Alexa Gushoff

source("Exam_data.R")
sanity_check

#Exercise 0################################################
sample(1:6, size = 2, replace = FALSE)
#1 3
#~ Good

#Exercise 1################################################
#1)
num_primes = length(primes) + 1 #returns length of vector (which contains all primes ≤ 500 except for 2)
cat("Number of primes: ", num_primes)
#~ Good

#2)
n = c(2: num_primes)
p_n = primes
P = data.frame(n, p_n)
View(P)
#~ Good

#3)
P$scaled_p_n = P$p_n / log (P$n)
View(P)
#~ Good

#4)
model = lm(scaled_p_n ~ n,data = P)
coef = coef(model)
r_2 = summary(model)$r.squared
cat("Intercept: ",coef[1]," n: ", coef[2]," R^2: ", r_2)
#~ Good

#5)
n_1 = length(primes[primes%%10 == 1])
n_3 = length(primes[primes%%10 == 3])
n_7 = length(primes[primes%%10 == 7])
n_9 = length(primes[primes%%10 == 9])
cat("Num of primes with last digit... 1:",n_1, " 3:",n_3," 7:",n_7," 9:",n_9)
if((n_1 == n_3)&&(n_3 == n_7)&&(n_3 == n_9)){
  cat("There are exactly as many primes with last digit 1,3,7 and 9.")
}else{
  cat("There are NOT equally as many primes with last digit 1,3,7 and 9.")
}
#~ Good, but do you believe that these 4 numbers are asymtpotically the same?
#
# chisq.test(c(n_1, n_3, n_7, n_9), p = rep(1/4, 4))
# Chi-squared test for given probabilities
#
# data:  c(n_1, n_3, n_7, n_9)
# X-squared = 0.36432, df = 3, p-value = 0.9475

#Exercise 3################################################
#1)
Z = read.csv("Exam_data_3.csv")
n_samples = nrow(Z)
cat(n_samples) #1000
#~ Good

#2)
mu = colMeans(Z)
cat(mu)
Sigma = cov(Z)
print(Sigma)
#A confidence region for a parameter µ \in R^3 is a random region C_α (α \in (0,1)), calculated from 
#sample data x_1,...x_n \in R^3, such that the true parameter µ lies in C_α with probability ≥ 1 - α:
# P(µ \in C_α) ≥ 1-α. 
#C_α is often centered around the mean X^{_} and constructed to have small volume. 
#There are several possibilities to construct confidence intervals/regions e.g. with help of
#Chebyschev Inequality. For that we require the true variance of each coordinate (X_1, X_2, X_3), since it is unknown we would use
#the empirical sample variances instead.
#Chebyschev Inequality for dim ≥ 2:
# P(||X^{_} - µ|| ≥ e) ≤ {sum_{j} V(X_j) }\{ n e^2} ≈{sum_{j} s_{x_j}^2 }/{ n e^2} := α
# After solving for e, the corresponding confidence region would be 
# C_α(X^{_}) = B(X^{_},sqrt{{sum_{j} s_{x_j}^2 }/{ n α}} )
#~ Good


#3)
var.test(Z$V1, Z$V2)
#The p-value of 0.3605 suggests not to reject the null hypothesis. 
#(If chosen any standard significance level (e.g., α = 0.05, 0.1) or any significance level α ≤ 0.3605.)
#The hypothesis that the variances of V1 and V2 are equal is therefore not implausible.
#4)
var.test(Z$V1, Z$V3)
#The p-value of < 2.2e-16 indicates that the null hypothesis must be rejected. 
#It is therefore highly implausible that V1 and V3 share the same variance.
#5)
plot(Z)
#V1 - V3 (lower right):
#The data points are more spread out along the y-axis than the x-axis (note the different scaling!).
#--> Different variances.

#V1 - V2:
#The data points are equally spread out along both axes --> Variances of similar size. 

#The results from the F-tests align with the visual evidence from the scatter plot. 
#~ Good

