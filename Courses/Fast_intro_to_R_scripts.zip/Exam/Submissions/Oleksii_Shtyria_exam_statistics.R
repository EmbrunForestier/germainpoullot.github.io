source("Exam_data.r")

sanity_check()


#Sample task numbers
a = trunc(runif(2,1,6))
print (a)
#~ Good

#Sampled tasks are:
#[1] 4 3

#Task 3

data = read.csv("Exam_data_3.csv")
n_rows = nrow(data)
print (paste("Number of 3D vectors in exam_data_3.csv file:", n_rows))
#~ Good

mu_hat = colMeans(data)
cat("Sample mean of the data is: (", mu_hat, ")\n")

#centered_data = sweep(data, 2, mu_hat, "-")
#sigma_hat = (1/(n_rows-1))*(t(as.matrix(centered_data)) %*% as.matrix(centered_data))

sigma_hat = cov(data)

print ("Sample covariance matrix is: ")
print (sigma_hat)

#Confidence region for mu is an ellipsoid centered at sample mean.
#~ Good, but insufficient explanation of confidence region...


print (var.test(data[,1],data[,2]))

#The null hypothesis of the F-test is that variances of two groups are equal
#When run on 1st and 2nd columns of the dataset, the F-test outputs a p-value of ca. 0.36
#This is way above typical thresholds to reject the null hypothesis
#We thus fail to reject the null hypothesis in the light of the data
#In other words, we are allowed (but not required) to assume that the 1st and 2nd
#data columns have the same theoretical variance despite the fact that 
#respective sample covariances differ

print (var.test(data[,3],data[,2]))

#F-test gives a minuscule p-value of 2.2e-16 for columns 2 and 3 of the dataset
#the p-value is way below typical thresholds for rejecting the null hypothesis
#sample variances of column 2 and 3 of the dataset differ so much that 
#in the light of the data one is no longer allowed to assume that 
#respective theoretical variances are the same
#put simpler, the null hypothesis that theoretical variances of column 2 and 3
#are identical is rejected in the light of the data

plot(data)

#slopes of the scatter plots seems to agree with data column covariance values
#off the main diagonal of the covariance
#those slopes are however hardly comparable if values of different columns
#are on different scales
#scale-normalized correlation plots would be more suitable to compare
#degrees to which values in different columns agree or disagree with
#one another 
#~ Good, incomplete but okay

#Task 4

nbr = 20

x = runif(nbr, 0, 1)
print (x)
y = runif(nbr, 0, 1)
print (y)

df = data.frame(X=x, Y=y)
#print (df)
#~ Good

#help(expand.grid)
df2 = expand.grid(X=x,Y=y)
#print (df2)
#~ Good

plot(df)
noisy_df = add_noise(df)
plot (noisy_df)

plot(df2)
noisy_df2 = add_noise(df2)
plot(noisy_df2)
#~ Good


print (cor.test(df[,1], df[,2]))
print (cor.test(noisy_df[,1], noisy_df[,2]))


print (cor.test(df2[,1], df2[,2]))
print (cor.test(noisy_df2[,1], noisy_df2[,2]))

#in all of four cases one fails to reject the null hypothesis that
#the the correlation between X and Y is 0
#for df and noisy the p-value is around 1/3
#for df2 and noisy_df2 it is above 0.9
#which if to be expected since df2 has been generated
#as a Cartesian product of X and Y vectors
#~ Good

new_df = subset(df, X<Y)
#colnames(new_df)
plot(new_df)
print (cor.test(new_df[,1], new_df[,2]))


new_noisy_df = subset(noisy_df, X<Y)
plot(new_noisy_df)
print (cor.test(new_noisy_df[,1], new_noisy_df[,2]))


new_df2 = subset(df2, X<Y)
#print (new_df2)
plot(new_df2)
print (cor.test(new_df2[,1], new_df2[,2]))


#new_noisy_df2 = noisy_df2[x<y,]
#new_noisy_df2 = subset(noisy_df2, X<Y)
new_noisy_df2 = noisy_df2[noisy_df2$X < noisy_df2$Y, ]
plot(new_noisy_df2)
print (cor.test(new_noisy_df2[,1], new_noisy_df2[,2]))

#for the (X<Y) filtered data p-values are:
#new_df1: 0.6249
#new_noisy_df: 0.4376
#new_df2: 5.656e-11
#new_noisy_df2: 3.147e-11

#the four filtered dataframes can thus be distinguished via their p-values
#of the correlation test

#for the Cartesian product dataframes after filtering,
#the null hypothesis that correlation between X and Y
#can be rejected
#~ Good


