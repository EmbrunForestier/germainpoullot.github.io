source("Exam_data.R")
sanity_check()

#---------------------------------------------
# Exercise 0
print(as.integer(runif(2, min=1, max=6))) #result: 3 1
#~ Good

#---------------------------------------------
# Exercise 1

# subtask 1
print(length(primes)+1) 

#output: 669 primes less than 5000
#~ Good

# subtask 2
P <- data.frame(2:(length(primes)+1), primes)
colnames(P) = c("n", "p_n")
#~ Good

# subtask 3
P$scaled_p_n <- P$p_n/log(P$n)
#~ Good

# subtask 4
model <- lm(scaled_p_n ~ n, data = P)
coefficients <- coef(model)
print(coefficients)
# result: b=1.142306, a=1.146882 for scaled_p_n = an +b
Rsquared <- summary(model)$r.squared
print(Rsquared)
# output: 0.9999388
#~ Good

# subtask 5
print(length(subset(P$p_n, P$p_n%%10 ==1)))
# 163 primes below 5000 have final digit 1
print(length(subset(P$p_n, P$p_n%%10 ==3)))
# 172 primes below 5000 have final digit 3
print(length(subset(P$p_n, P$p_n%%10 ==7)))
# 169 primes below 5000 have final digit 7
print(length(subset(P$p_n, P$p_n%%10 ==9)))
# 163 primes below 5000 have final digit 9

# result: final digits don't have exactly same frequency but close to it
#~ Good: how much do you believe in them being asymptotically equal ?


# ---------------------------------------------------

# Exercise 3

# subtask 1
Z <- read.csv("Exam_data_3.csv")
print(nrow(Z)) # amount of samples for the 3-dimensional vector: 1000
#~ Good

# subtask 2
# estimator for the expectation
print(c(mean(Z$V1), mean(Z$V2), mean(Z$V3))) #result:  (0.97199346, -0.05823839, -1.03083784)
# estimator for the covariance matrix
print(cov(Z)) 
#result:
#           V1       V2         V3
#V1  2.0125583 0.617523 -0.3154992
#V2  0.6175230 1.899384  3.8007502
#V3 -0.3154992 3.800750 19.7593642
#~ Good, but insufficient explanation of confidence region (in attached PDF).

# subtask 3
var.test(Z$V1,Z$V2)
# result (only most important information mentioned, for the interpretation see the pdf): F = 1.0596, p = 0.3605
#~ Good (conclusion in PDF)

# subtask 4
var.test(Z$V1, Z$V3)
# result (only most important information mentioned, for the interpretation see the pdf): F = 0.0185, p < 2.2*10^{-16}
#~ Good (conclusion in PDF)


#subtask 5
plot(Z)
#~ Excellent comments in PDF