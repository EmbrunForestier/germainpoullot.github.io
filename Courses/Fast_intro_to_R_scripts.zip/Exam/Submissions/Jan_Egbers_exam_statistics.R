source("Exam_data.R")
sanity_check()

as.integer(runif(2, min = 1, max = 6))
#4,5

#Task 4)
#1.
nbr <- 20
X <- runif(nbr,0,1)
Y <- runif(nbr,0,1)
df <- data.frame(X,Y)
#~ Good

#2.
?expand.grid
df2 <- expand.grid(X=X,Y=Y)
#~ Good

#3.
plot(df)
plot(df2)
noisy_df <- add_noise(df)
noisy_df2 <- add_noise(df2)
plot(noisy_df)
plot(noisy_df2)
#~ Good

#4.
cor.test(df$X, df$Y)
# These were the results when the code was tested (This changes depending on the values randomly chosen
# for X and Y):
#Pearson's product-moment correlation
#data:  df$X and df$Y
#t = 0.98931, df = 18, p-value = 0.3356
#alternative hypothesis: true correlation is not equal to 0
#95 percent confidence interval:
# -0.2394971  0.6084659
#sample estimates:
#      cor 
#0.2270914

# The cor.test()-function uses a t-test to analyse how likely this sample is given the Null-hypothesis
# of correlation-coefficient between X and Y being zero. Under the hypothesis of this factor being zero, and
# under the (in this case false) assumption that X and Y follow a normal distribution, the fraction of the
# estimated correlation-coefficient of X and Y divided by the estimator for its standard deviation follows the
# student-t-distribution with nbr-2 degrees of freedom, here: 20-2 =18. As I will keep performing the same test
# on different data, the Null-hypothesis will stay the same throughout task 4.
# Here, t is, under the given sample, the realised value of the construct we assume to follow
# the t-distribution.
# With this data 0.22709... is an estimator for the correlation-coefficient between X and Y and the 95%-
# confidence interval marks the range calculated via a process which is designed in a way such that the
# result tends to includes the true value of the correlation-coefficient in 95% of all outputs as the number
# of process-applications tends to infinity. The values for the 95% confidence interval aren't too
# trustworthy, since the uniform distributions of X and Y skew the results of the calculation. 
# The p-value is the critical value for alpha in order to reject the Null-hypothesis under the given sample:
# for alpha above the p-value we reject the hypothesis while for values of alpha below the p-value the sample
# doesn't provide sufficient cause to reject it. It is important to emphasise that the value for alpha has to
# be chosen before the data is analysed (preferably before the data is collected) as to avoid choosing a
# value that fits the result we want to see. In order to follow a constant standard throughout this task I 
# choose alpha to be 0.05 in an attempt to balance the likelihood of rejecting the Null-hypothesis even though
# it is true with the likelihood of not rejecting it even though it is false.
# Here, since the p-value is slightly above 1/3 we do not reject the hypothesis of the correlation-coefficient
# being zero for the chosen value of alpha. 
#~ Very good


cor.test(df2$X, df2$Y)
#Pearson's product-moment correlation
#data:  df2$X and df2$Y
#t = -2.3711e-20, df = 398, p-value = 1
#alternative hypothesis: true correlation is not equal to 0
#95 percent confidence interval:
# -0.09805172  0.09805172
#sample estimates:
#          cor 
#-1.188513e-21 

# We apply the same test as before, however the 20*20=400 data points result in 398 degrees of freedom.
# The estimate for the correlation-coefficient is around -1e-21, very close to zero. Forthermore, since the
# p-value lies as far beyond the pre-chosen alpha as possible, we do not reject the Null-hypothesis.
#~ Good

cor.test(noisy_df$X, noisy_df$Y)
#Pearson's product-moment correlation
#data:  noisy_df$X and noisy_df$Y
#t = 0.9694, df = 18, p-value = 0.3452
#alternative hypothesis: true correlation is not equal to 0
#95 percent confidence interval:
# -0.2438027  0.6055781
#sample estimates:
#      cor 
#0.2227501 

# This result is very similar to the first one. With the p-value lying above the alpha-value, we
# do not reject the hypothesis.
#~ Good

cor.test(noisy_df2$X, noisy_df2$Y)
#Pearson's product-moment correlation
#data:  noisy_df2$X and noisy_df2$Y
#t = -0.058932, df = 398, p-value = 0.953
#alternative hypothesis: true correlation is not equal to 0
#95 percent confidence interval:
#  -0.10097646  0.09512529
#sample estimates:
#  cor 
#-0.002953986

# Here, the result mirrors that of the second analysis. For alpha = 0.05 we once again do not reject the
# Null-hypothesis. However, while the effect of the add_noise() function was only minor before, in this case
# it causes the correlation factor to be roughly 18 orders of magnitude higher than before. Nonetheless,this
# doesn't change our non-rejection of the hypothesis. 
#~ Very good

#5.
df <- df[df$X < df$Y, ]
df2 <- df2[df2$X < df2$Y, ]
noisy_df <- noisy_df[noisy_df$X < noisy_df$Y, ]
noisy_df2 <- noisy_df2[noisy_df2$X < noisy_df2$Y, ]

plot(df)
plot(df2)
plot(noisy_df)
plot(noisy_df2)
cor.test(df$X, df$Y)
#Pearson's product-moment correlation
#data:  df$X and df$Y
#t = 2.609, df = 12, p-value = 0.02284
#alternative hypothesis: true correlation is not equal to 0
#95 percent confidence interval:
# 0.1043326 0.8582378
#sample estimates:
#     cor 
#0.601609 

# Reducing the number of points has also decreased the degrees of freedom from 18 to 12. Our p-value is only
# about half of our chosen alpha. Thus, we reject the hypothesis. 
# Compared to before, the estimate for the correlation-coefficient has nearly tripled to around 0.6. 
# This aligns with expectations since the filter specifies that the Y-values of the pointts must be larger
# than the X-values, thus, we force a more concrete relationship. Besides explaining the increased correlation
# factors, this relationship also decreases the p-value, since we can now expect the relation: large X-value 
# implies large Y-value. Therefore, we can expect our new, filtered data to be less likely to occur under the
# Null-hypothesis. 
#~ Good

cor.test(df2$X, df2$Y)
#Pearson's product-moment correlation
#data:  df2$X and df2$Y
#t = 7.1774, df = 267, p-value = 7.034e-12
#alternative hypothesis: true correlation is not equal to 0
#95 percent confidence interval:
# 0.2968442 0.4978183
#sample estimates:
#      cor 
#0.4021645 

# This time, due to the limitation of data points, the test went down to 267 degrees of freedom. 
# Furthermore, with our p-value being 7.034e-12 we reject the hypothesis since alpha is far larger. This is in
# contrast to the unfiltered datapool where the analysis could not find sufficient reason to reject the
# hypothesis.
# The estimate for the correlation-coefficient is also around 20 orders of magnitude higher than before
# filtering the data.
#~ Good

cor.test(noisy_df$X, noisy_df$Y)
#Pearson's product-moment correlation
#data:  noisy_df$X and noisy_df$Y
#t = 2.4994, df = 12, p-value = 0.02794
#alternative hypothesis: true correlation is not equal to 0
#95 percent confidence interval:
# 0.07909356 0.85138411
#sample estimates:
#      cor 
#0.5851183

# Here, since the p-value is below alpha, we reject the Null-hypothesis. This, too, stands in contrast to the
# unfiltered data where the hypothesis was not rejected. Once again, and as expected, our correlation-
# coefficient increased after filtering the data.
#~ Good, yes but here the explanation is rather that we don't have enough data points...

cor.test(noisy_df2$X, noisy_df2$Y)
#Pearson's product-moment correlation
#data:  noisy_df2$X and noisy_df2$Y
#t = 7.081, df = 267, p-value = 1.267e-11
#alternative hypothesis: true correlation is not equal to 0
#95 percent confidence interval:
# 0.2919056 0.4937403
#sample estimates:
#     cor 
#0.397622

# In this final test for the task 4, we once again reject the hypothesis on the grounds that alpha far exceeds
# the p-value. The p-value in this case is even smaller than the one in the noiseless and filtered test on
# the points of the expanded grid, making the data even more unlikely under the Null-hypothesis.
#~ Good


#Task 5)
#1.
nbr <- 75
rg <- 4
X <- sort(runif(nbr,0,20))
df <- data.frame(X=X, Y=f(X))
#~ Good

#2.
ddf <- data.frame(X=X, dY=NA, InterceptY=NA)
#~ Good

#3.
for (k in (1 + rg):(nbr - rg)) {
  sub_df <- df[k-rg:k+rg, ]
  model <- lm(Y~X, data = sub_df)
  ddf$dY[k] <- model$coefficients[2]
  ddf$InterceptY[k] <- model$coefficients[1]
}
#~ WRONG: missing parentheses in: sub_df <- df[(k-rg):(k+rg), ]

#4.
plot(df)
draw_derivatives(ddf, rg+2)
# As can be inferred from the plot and seen in its definition, the function f has a periodic fluctuation as
# deviation from a general linear decline, as well as a normally distributed error from this deterministic
# aspect. 
# The slopes generated by the linear model via a least-squares-approach for each subset of consecutive points 
# are crude estimators for the derivative of the function f in the points (X,Y=f(X)). 
# For the linear model we
# assume there to be a mostly linear relationship between X and Y on each chosen subset of points.
# Additionally, we assume that besides the linear relationship (linear in the sense of a polynomial of degree
# one, not in the sense of linear operators) there is a small normally distributed error term shifting the
# values of f(x) astray from the strict linear dependence on X. From the definition for f, we know the error-
# term to be normally distributed with standard deviation 0.075. While this fits our second assumption we can
# also see that the one specifying the linear relationship does not hold because while there is a linear
# component, f also contains periodic aspects that do not fit any of our base assumptions. Shifting this aspect
# into the assumption of linearity would cause the relationship to stop being linear whilst shifting it into
# the error-term would both deviate from the normal distribution as well as from the idea that the error-term
# is small. Therefore, since the assumptions are not fulfilled, we cam conclude that the linear model does not
# return good estimators for the derivative at the given points.
# The calculated estimator for the slope is equal to the fraction of the empirical covariance between
# X and Y divided by the empirical variance of X. The resulting estimator for the Y-intercept is the
# mean value of Y minus the product of the slope-estimator and the mean value of X, always only on the X 
# and Y values of the points contained in the sub-dataframe.
# Assumably, if the linear model didn't punish large deviances as harshly, the effect of the far points,
# compared to the ones closer to the point of which we want to approximate the derivative, wouldn't influence
# the model's coefficients as much, thus strengthening the effect of the more adjacent points. This could for
# example be done by specifying fitting weights to apply in a weighted least-squares-method. 
# The result would probably be a better estimator for the derivative. With the given approach, the general
# trend is weight more heavily than the periodic fluctuation likely because of the sparce population of points
# within the plot.
# The estimator for the derivative could also be improved by reducing the value of rg, thereby nullifying the
# effect of the not so closely adjacent points.

#~ Yes but no
 
#5.
local_min <- numeric(0)
for (k in (1 + rg +1):(nbr - rg-1)) { #+-1 to avoid comparing with NA
  if(ddf$dY[as.numeric(k)-1]<0 && ddf$dY[as.numeric(k)+1]>0){
    local_min <- c(local_min, as.numeric(k))
  }
} 
rug(df$X[local_min], side = 1, col = "red", lwd = 2)
#~ Yes but no
