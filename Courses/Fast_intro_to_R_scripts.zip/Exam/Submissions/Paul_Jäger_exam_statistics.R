source("/home/GreyEminxnce/GitServer/University/06_Semester/Statistics/Examination/Project/Exam_data.R")

sanity_check()

# Exercise 0
exercises <- as.integer(runif(n = 2, min = 1, max = 6))
# Result: Exercise 2 and 3 - it actually only took 3 tries 
#   (it wasn't prohibited to run the script again :))
#   the probability of sampling {2, 3} is 2 / 25, 
#   so 12.5 tries would be expected (geometric distribution)

# Fun Fact 1: As of Exercise 0, nothing is stated about the sampled pair 
#   not being allowed to consist of the same number so that one 
#   would only need to do 1 exercise (my first roll was (3, 3)), 
#   the chance for that is 5 / 25 = 1 / 5.
# Fun Fact 2: It wasn't specified whether the continuous uniform distribution 
#   or discrete (on the integers from 1 to 6) was meant.
#   Under the discrete model, there would be a 1 / 36 chance to get the result 
#   (6, 6) so that one doesn't need to do anything as the actual exercises 
#   are numbered from 1 to 5.
#   (In the continuous case this isn't possible in R: "runif will not generate 
#   either of the extreme values unless max = min or max-min is small 
#   compared to min, and in particular not for the default arguments."
#   However, even if max could be generated, the probability would be 0.)

#~ Good

# Exercise 2:
## 2.1
# density (pdf):                     dcauchy()
# cumulative distribution function:  pcauchy()
# quantile function:                 qcauchy()
# random sampling ("r"):             rcauchy()
#~ Good

## 2.2
N <- 1 : 1000
C <- data.frame(N)
for (n in C$N){
    samples <- rcauchy(n) # To use them for both statistics
    C$Mean[n] <- mean(samples)
    C$Standard_Deviation[n] <- sd(samples) # For n = 1 not well-defined (0 / 0)
}
View(C)

## 2.3
plot(x = C$N, y = C$Mean, xlab = "n", ylab = "Mean")
plot(x = C$N, y = C$Standard_Deviation, xlab = "n", ylab = "Standard deviation")

# The Cauchy distribution has heavy tails; its expectation does not exist
#   in the Lebesgue sense as one would compute (+infinity) - (+infinity).
# Yet, the Cauchy principal value is 0 because the pdf is symmetric around 0.
# This is why the empirical mean seems to be centered around 0
#   but not converging to it (due to large outliers from the heavy tails).
#   This is no contradiction to the SLLN as the SLLN assumes finite expectation.
#   This is not fulfilled for the Cauchy distribution.

# The empirical standard deviation behaves very erratically:
# On average, the amount and size of the outliers seem to increase 
#   and the number of sample standard deviations near zero seems to decrease.
#   (Can't be visually seen when outliers of too big size exist.)
# This is at least intuitive as the variance of the Cauchy distribution 
#   isn't defined (as the integral would be infinity).
#~ Good, but I think the last part is just an illusion.

## 2.4
plot(x = C$N, y = C$Standard_Deviation, xlab = "n", ylab = "Standard deviation",
     col = ifelse(abs(C$Mean) >= 10, "red", "black"))

# If the mean is large in absolute value, then at least one large sample 
#   (in absolute value) has to exist.
# It is unlikely that most samples are around the big mean 
#   as all of them would have to be big and of the same sign.
#   This is unlikely even with the heavy tails because the pdf has 
#   most mass near 0 and is symmetric.
# Therefore, if we have a big mean, we usually have big differences 
#   in the sample values leading to a big empirical standard deviation.

# Vice versa, if the sample standard deviation is very high, 
#   then there at least needs to be one big sample (in absolute value).
# As it is unlikely that the other samples compensate for this 
#   (again, as the pdf has most mass near 0 and is symmetric 
#   (so getting a big value of different sign is as likely as one of same sign))
#   the mean is likely large in absolute value as well.

# Hence, the red points (large |mean|) mostly coincide 
#   with large sample standard deviations.
#~ Good code, but over-interpretating slightly: first, heavy-tailed means heavy tailed: one cannot argue about a concentration around the mode when there is an heavy tail; second, the variance can be high with low mean, especially if n is large because nothing forbids from adding a lot of small (x_i - \overline{x})^2.

## 2.5
new_samples <- rcauchy(1000)
inverse_samples <- 1 / new_samples
ks.test(x = inverse_samples, pcauchy)
# data:  inverse_samples
# D = 0.017555 - sup distance
# p-value = 0.9176 - probability threshold; reject H_0 if alpha is bigger
# alternative hypothesis: two-sided - meaning: test for equality

# The p-value is very high (0.9176) in that it would require an 
#   alpha > 0.9176 to reject H_0 which would be extremely high and unreasonable.
# (This matches the theoretical fact that X ~ Cauchy  =>  1/X ~ Cauchy.)
#~ Good. I got p-value = 0.01423 in my test. Explain.


# Exercise 3

## 3.1
Z <- read.csv("/home/GreyEminxnce/GitServer/University/06_Semester/Statistics/Examination/Project/Exam_data_3.csv") # Returns a data frame
Z_amount <- nrow(Z) # Number of rows, doesn't count first line/column names
print(Z_amount) # There are 1000 samples

## 3.2
Z_mean <- colMeans(Z) # means for each column (here dimension)
print(Z_mean)

Z_covariance_matrix <- cov(Z)
print(Z_covariance_matrix)

# A confidence set/interval is a random set/interval in which a (fixed) 
#   quantity lies with at least probability 1 - \alpha 
#   (probability wrt the set).
# Usually confidence sets are constructed via some point estimator 
#   of the quantity and then some region around it 
#   for which one has at least (an approximation on) a bound on the probability.
# A confidence set for the expected value can be constructed 
#   via the empirical mean and the (empirical) variance.
# Explicitly, it can be constructed via Chebyshev:
#   For a confidence level of 1 - \alpha, we get a 2-norm ball 
#       around the sample mean with radius 
#   $$\sqrt{\frac{\sum_{j=1}^3 \mathbb{V}[X_j]}{n \cdot \alpha}}$$
#   \mathbb{V}[X_j] denotes the variance of the j-th coordinate of the RV.
#   We know n = 1000, and if the variance is known, this lets us construct one.
#   If it is unknown, it can be estimated by the empirical variance, but this
#       in itself does not give us any guarantee on the probability.
#~ Good

## 3.3
var.test(Z$V1, Z$V2)
# ratio of variances: 1.059585
# p-value = 0.3605 - so under any level alpha < 0.3605, we don't reject 
# At all conventional levels (0.01, 0.05, 0.10) 
# we don't reject that they have equal variances.
#~ Good

## 3.4
var.test(Z$V1, Z$V3)
# ratio of variances: 0.1018534 - V3 has much higher variance than V1
# p-value < 2.2e-16 - The p-value is extremely small.
# We reject that the variances are the same.
#~ Good

## 3.5
plot(Z)
# plot(Z) is a scatterplot plotting each pair of coordinates against each other.
# The ij-th plot is the ji-th with swapped dimensions (Vi vs. Vj / Vj vs. Vi) 
#   The symmetry is easiest to see when the panels are square.
# It agrees with the F-tests from the previous two questions: 
#   The spread of points in a coordinate in terms of the length of the interval 
#   and "distribution" in the interval (meaning where the points are located)
#   are visual clues for its empirical variance in that coordinate:
#   The longer the interval and the more points on the edges of the interval,
#   the higher the empirical variance.

# Considering the plots of V1 vs. V2, 
#   the spread of the samples is roughly equal:
# V1 ranges roughly from -4 to 6 and V2 from -4 to 5 
#   (& they are "distributed" similarly (most in the middle, few at the edge))
# This agrees with the similar empirical variances.

# Considering the plots of V1 vs. V3, 
#   the spread of the samples is very different.
# V1 ranges roughly from -4 to 6 and V3 from -16 to 13 
#   (& they are "distributed" similarly (most in the middle, few at the edge))
# This agrees with the fact that the empirical variance of V3 is way higher
#   than the one of V1.

# In reference to task 3.2:
# The empirical correlation (without explicit calculation) 
#   can be seen by analyzing the shapes of the plots:
#   The plot of V2 vs. V3 has a clear trend from the bottom left 
#    to the top right fitting to the positive empirical correlation.
#   The plot of V1 vs. V2 has the same but to a lesser degree 
#       aligning with the moderate positive empirical correlation.
#   The plot of V1 vs. V3 has a very small trend from the top left 
#       to the bottom right; however, it looks mostly untilted/axis-aligned 
#       fitting to the near 0 (negative) empirical correlation.

# Also, the empirical means are roughly
#         V1          V2          V3 
# 0.97199346 -0.05823839 -1.03083784
# corresponding to them being fairly in the center of the plots.
# (Using that the marginals are symmetric around the means
#   because they are normally distributed.)

# In reference to task 3.1:
# In theory, the amount of points per plot should be the total amount of samples
#   which is 1000.
#   One could try to count them; however, my monitor isn't big enough and
#   doesn't have enough pixels to properly distinguish 
#   and therefore count points :)

#~ Very good
