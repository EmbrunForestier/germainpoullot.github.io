source("Exam_data.R")

#exercise 0:
two_exercises <- sample(1:6, 2, replace = TRUE)
print(two_exercises)
# result: [1] 3 1 -> I have to work on exercise 1 and 3
#~ Good, but why "replace = TRUE", you want "replace = FALSE" actually...

#########################################################################
#exercise 1.1:
number_of_primes = length(primes)+1
print(number_of_primes)
# result: [1] 669 -> there are 669 prime numbers less than 5000 
#(primes contain all primenumbers less than 5000 except the number 2. 
#Therefore, the length of the primes vector + 1 is the number of primes less than 5000.)
#~ Good

#exercise 1.2:
n = c(2:number_of_primes)
dataframe <- data.frame(n,primes)#creates table with 2 coloumns, one coloumn = one vector
print(dataframe)
#~ Good

#exercise 1.3:
scaled_p_n <- primes/log(n)
dataframe_2 <- data.frame(n,primes,scaled_p_n)
print(dataframe_2)
#~ Good: well... you created a new table here. That's not what is asked and that's bad in term of memory usage.

#exercise 1.4:
result <- lm(scaled_p_n~n)#linear model, n depends on scaled_p_n
summary(result)
#Coefficients (for ax+b):intercept(b)=1.1423057, slope(a)=1.1468816
#Multiple R-squared:  0.9999,	Adjusted R-squared:  0.9999 
#~ Good

#exercise 1.5:
last_digits_of_primes <- primes %% 10
table(last_digits_of_primes)
#  1   3   5   7   9 ---> for 1 and 9 the claim is true, for 3 and 7 not
#163 172   1 169 163 
#~ Good: do you think that the difference between 163 and 172 is significant here? Do you believe the conjecture or not?


#########################################################################
#exercise 3.1:
Z <- read.csv("Exam_data_3.csv")# Z is a data.frame
#print(Z)
#~ Not good: where is the size of "Z"?

#exercise 3.2:
mu_hat <- colMeans(Z)# compute mean value estimator (=mü_^=mü_hat) of sample Z
sigma_hat <- cov(Z)# compute covariance matrix estimator (=sigma) of sample Z
print(mu_hat)
print(sigma_hat)
#~ Good

# A confidence region for mu: Since Z in R^3, a confidence region C_alpha is a ball around the 
# estimator mu_hat, with radius depending on the estimated variances (diagonal of Sigma_hat), 
# the sample size n, and the chosen significance level alpha.
# --> C_alpha(Z_bar) = B(center, radius )= B( mu_hat, sqrt( sum_j Var(X_j) / (n*alpha) ) ),
#~ Good: Yes. Can you improve this region using the PCA (diagonalisation of cov(Z))?

#exercise 3.3:
result_f <- var.test(Z[,1], Z[,2])
print(result_f)
# F = 1.0596, num df = 999, denom df = 999, p-value = 0.3605
# alternative hypothesis: true ratio of variances is not equal to 1
# 95 percent confidence interval:
#  0.9359298 1.1995769
# sample estimates:
# ratio of variances 
#           1.059585 
# H0: coloumn 1 and 2 of sigma have same variance 
# --> reject H0 if p-value < alpha  
# --> for alpha = 0.05 dont reject H0 (p-value= 0.3605 > 0.05 = alpha)
#~ Good

#exercise 3.4:
result_f <- var.test(Z[,1],Z[,3])
print(result_f)
# p-value < 2.2e-16
# --> p-value < alpha=0.05 
# --> first and third coordinate dont have the same variance
#~ Good

#exercsie 3.5:
png("Z_plot.png")
plot(Z)
dev.off()
# The scatterplot matrix confirms the numerical results:
# V1 and V2 have similar axis ranges (-4 to 4), consistent with the F-test
# in part 3 (no evidence against equal variance, p=0.36).
# V3 has a much wider range (-15 to 10), clearly larger spread than V1/V2,
# consistent with part 4's result (significantly different variance, p<2.2e-16).
#~ Good: Ask questions on PCA.
