# You need to download the file "Exam\_data.R" and save it in the same folder as your future script.
# Open \Rlogo, create a new script, and start your script by \texttt{source("Exam\_data")} then run \texttt{sanity\_check()}.
# If you do not get \texttt{TRUE} as an answer, open manually the file "Exam\_data.R", then copy-paste the whole file at the begining of your script and run its lines one-by-one.

rm(list=ls())
source("Exam_data.R")
sanity_check()




# 0) Sample to numbers uniformly between 1 and 6, then take their integer values. These two numbers designate the two questions you will have to solve.

as.integer(runif(2, 1, 6))




# 1) The variable \texttt{primes} from the source file contains all prime numbers less than $5\,000$ (the number $2$ has been removed).
# \begin{compactenum}
# \item How many prime numbers are they less than $5\,000$?
# \item Construct a \texttt{data.frame} named \texttt{P} with a column \texttt{n} ranging from $2$ to the correct number, and a second column \texttt{p\_n} with the content of the variable \texttt{primes}.
# \item According to Hadamard--La-Vallée-Poussin theorem on prime numbers, the sequence $\frac{p_n}{\ln n}$ is asymptotically equivalent to $n$.
# Add a third column named \texttt{scaled\_p\_n} which is equal to $n\cdot p_n$.
# \item Check Hadamard--La-Vallée-Poussin theorem by performing a linear fit in the formula \texttt{scaled_p_n $\sim$ n}. Give the coefficients and the $R^2$.
# \item[Oral question:] How to run the linear model using only the first $10$ primes? What do you expect on $R^2$?
# \item[Oral question:] How to extract only the primes of the form $4k+1$?
# \item[Oral question:] How to plot $p_n$ as a function of $n$, in red?
# \end{compactenum}

nb = length(primes)
nb

P = data.frame(n = c(2:(nb+1)), p_n = primes)
View(P)

P$scaled_p_n = P$p_n / log(P$n)

model = lm(scaled_p_n ~ n, data = P)
coef(model)
summary(model)$r.squared

model = lm(scaled_p_n ~ n, data = P[1:10, ])
coef(model)
summary(model)$r.squared

length(primes[primes %% 4 == 1])

plot(x = P$n, y = P$scaled_p_n, col = 'blue')
plot(x = P$n, y = P$p_n, col = 'red')



# 2) You have seen in the course that the expectation of the Cauchy distribution is infinite.
# \Rlogo has built-in functions for the Cauchy distribution. You can sample from it using \texttt{rcauchy(...)}.
# \begin{compactenum}
# \item What are the names of the functions yielding the density function, the probability distribution, and the quantiles of the Cauchy distribution.
# \item Construct a \texttt{data.frame} named \texttt{C} with column \texttt{N} ranging from taking values $k\in \{1, \dots, 1\,000\}$.
# \item Add two columns to \texttt{C}, named \texttt{Mean} and \texttt{Standard\_Deviation} whose values are the means and the standard deviations of $n$ samples of the Cauchy distribution (where $n$ is the value in \texttt{C$N}). Comment the result.
# \item Plot the means and the standard deviations you have obtained.
# \item A friend tells you that if $X$ is Cauchy distributed, then $1/X$ is also Cauchy distributed. Sample $1000$ times the Cauchy distribution and run a Kolmogorov--Smirnov test for the null hypothesis ``$\frac{1}{x_1}, \dots, \frac{1}{x_{1000}}$ is not Cauchy distributed.''. Conclude.
# \item[Oral question:] In the result of the \texttt{ks.test}, what does ``two-sided'' means? What does the \texttt{statistic} (i.e. \texttt{D}) indicates?
# \item[Oral question:] How to plot the density of the Cauchy distribution between $-1$ and $1$, in red?
# \item[Oral question:] What is the domain of definition of \texttt{qcauchy}? If I execute \texttt{qcauchy(2)}, what would I get?
# \end{compactenum}

?dcauchy
?pcauchy
?qcauchy

C = data.frame(N = c(1:1000))

for (k in C$N) {
  Cau = rcauchy(k)
  C$Mean[k] = mean(Cau)
  C$Standard_Deviation[k] = sd(Cau)
}

plot(x = C$N, y = C$Mean)
plot(x = C$N, y = C$Standard_Deviation)

points(x = C$N[abs(C$Mean) >= 10],  y = C$Standard_Deviation[abs(C$Mean) >= 10], col = 'red')

KS = ks.test(1/rcauchy(1000), "pcauchy")
KS
View(KS)
KS$statistic

plot(dcauchy, xlim=c(-1, 1), col = 'red')

qcauchy(2)



# 3) The file "Exam_data_3.csv" is a .csv file containing 3-dimensional vectors, one vector per row.
# These vectors are samples of a normal distribution $\c N(\b \mu, \Sigma)$.
# \begin{compactenum}
# \item Read this .csv file and store its contain in a variable \texttt{Z}. How many samples are they?
# \item Estimate $\b \mu$. and $\Sigma$. What is a confidence region for $\b\mu$?
# \item Looking at $\Sigma$, it seems that the two first coordinates have the same variance. Run and interpret a F-test, using \texttt{var.test(...)}, to verify this hypothesis.
# \item Run a F-test between the first and the third coordinate and interpret the result.
# \item Run \texttt{plot(Z)}: does what you see agree with the results of the previous questions?
# \item[Oral question:] I have computed the eigenvalues of the estimated $\Sigma$, namely: $20.5, 2.47, 0.766$. Why are they positive?
# \item[Oral question:] The first coordinate of the eigenvector associated to $20.5$ is (approximately) $0$. What are its two other coordinates?
# \item[Oral question:] I want to check that the expansion formula for $\V(Z_1 + Z_2)$ holds where $Z_i$ is the $i^{\text{th}}$ coordinate of $Z$. How to do with \Rlogo?
# \end{compactenum}

# # True parameters: $\b\mu = (1, 0, -1)$, and $\Sigma = \begin{pmatrix} 2 & 0.6 & -0.4 \\ 0.6 & 2 & 4 \\ -0.4 & 2 & 20 \end{pmatrix}$.

Z = read.csv("Exam_data_3.csv")

dim(Z)

mean(Z[,1])
mean(Z[,2])
mean(Z[,3])

S = cov(Z)
S

var.test(Z[,2], Z[,1])
var.test(Z[,3], Z[,1])

plot(x = Z[,1], y = Z[,2])
plot(x = Z[,1], y = Z[,3])
plot(Z)

eigen(S)

var(Z[,1] + Z[,2]) == S[1, 1] + S[2, 2] + 2 * S[1, 2]



# 4) The file ``Exam\_data.R'' provides a function \texttt{add\_noise}.
# \begin{compactenum}
# \item Write and run \texttt{nbr = 20}. Create two columns \texttt{X} and \texttt{Y} containing \texttt{nbr} samples of the uniform distribution on $[0, 1]$. Create a \texttt{data.frame} called \texttt{df} containing the columns \texttt{X} and \texttt{Y} you have created.
# \item Call the manual to understand the function \texttt{expand.grid}. Create a \texttt{data.frame} called \texttt{df2} containing two columns named \texttt{X} and \texttt{Y} but containing one rows for each $(x_i, y_j)$ where $x_i \in$\texttt{X} and $y_j\in$\texttt{Y}.
# \item Plot \texttt{df} and plot \texttt{df2}. Run \texttt{noisy_df = add_noise(df)} and \texttt{noisy_df2 = add_noise(df2)} and plot the result.
# \item We want to distinguish between the two types of data. Run \texttt{cor.test} on the four data frame and comment the results.
# \item Filter your four tables under the condition that the $x$-value is smaller than the $y$-value, plot and re-run the correlation tests on the four filtered tables. Comment the results.
# \item[Oral question:] How to compute the covariance matrix. What do you expect to see in the eight cases?
# \item[Oral question:] How to compute the marginal distribution on the $x$-axis? If I run a Kolmogorov--Smirnov test against the uniform distribution, what should I expect in the eight cases?
# \item[Oral question:] How to do if I want to plot \texttt{X} on the vertical axis and \texttt{Y} on the horizontal axis instead?
# \end{compactenum}

nbr = 50
X = runif(nbr, 0, 1)
Y = runif(nbr, 0, 1)

df = data.frame(X, Y)

?expand.grid
df2 = expand.grid(X = X, Y = Y)

noisy_df = add_noise(df)
plot(df)
plot(noisy_df)

noisy_df2 = add_noise(df2)
plot(df2)
plot(noisy_df2)

?cor.test

cor.test(df$X, df$Y)
cor.test(noisy_df$X, noisy_df$Y)
cor.test(df2$X, df2$Y)
cor.test(noisy_df2$X, noisy_df2$Y)


df3 = df[df$X <= df$Y, ]
noisy_df3 = noisy_df[noisy_df$X <= noisy_df$Y, ]
df4 = df2[df2$X <= df2$Y, ]
noisy_df4 = noisy_df2[noisy_df2$X <= noisy_df2$Y, ]

plot(df3)
plot(noisy_df3)
plot(df4)
plot(noisy_df4)

cor.test(df3$X, df3$Y)
cor.test(noisy_df3$X, noisy_df3$Y)
cor.test(df4$X, df4$Y)
cor.test(noisy_df4$X, noisy_df4$Y)

cov(df)
cov(noisy_df)
cov(df2)
cov(noisy_df2)
cov(df3)
cov(noisy_df3)
cov(df4)
cov(noisy_df4)

ks.test(noisy_df$X, punif)
ks.test(noisy_df2$X, punif)
ks.test(noisy_df3$X, punif)
ks.test(noisy_df4$X, punif)

plot(x = noisy_df4$Y, y = noisy_df4$X)




# 5) In the file ``Exam\_data.R'' contains a function \texttt{f} and a function \texttt{draw\_derivatives}.
# \begin{compatcenum}
# \item Write and run \texttt{nbr = 75} and \texttt{rg = 4}. Create a column \texttt{X} containing \texttt{nbr} samples of the uniform distribution on $[0, 20]$. Sort these samples, and create a \texttt{data.frame} called \texttt{df} containing the columns \texttt{X} and \texttt{Y = f(X)}.
# \item Create a \texttt{data.frame} named \texttt{ddf} whose first column is \texttt{X}, second column is named \texttt{dY} and is full of \texttt{NA}, and third column is named \texttt{InterceptY} and is full of \texttt{NA}.
# \item For each \texttt{k} between \texttt{1+rg} and \texttt{nbr-rg}, construct \texttt{sub\_df} to be the \texttt{data.frame} containing the rows of \texttt{df} from \texttt{k - rg} to \texttt{k + rg}. Compute the linear regression for \texttt{Y} against \texttt{X} for the data of this \texttt{sub\_df}, and store the resulting coefficient linear coefficient in \texttt{ddf$dY} and the constant coefficient in \texttt{ddf$InterceptY}.
# \item Plot \texttt{df}, and run \texttt{draw\_derivatives(ddf, rg+2)}. Comment the result.
# \item Some $x$-value \texttt{X[k]} is a \emph{local minimum} of \texttt{f} if \texttt{dY[k-1]} is negative and \texttt{dY[k+1]} is positive. Find the local minima of \texttt{f}, and add them in red on the horizontal axis of the plot.
# \item[Oral question:] How to find the local maxima?
# \item[Oral question:] What do you expect as \texttt{rg} grows?
# \item[Oral question:] How can I compute the second derivative of a function? What would be the problem?
# \end{compactenum}

nbr = 75
rg = 2

X = runif(nbr, 0, 20)
X = sort(X)
df = data.frame(X = X, Y = f(X))
# plot(df)

ddf = data.frame(X = df$X, dY = NA, InterceptY = NA)
for (k in (rg + 1):(nbr - rg)) {
  sub_frame = df[(k - rg):(k + rg), ]
  model = lm(Y ~ X, data = sub_frame)
  ddf$dY[k] = coef(model)['X']
  ddf$InterceptY[k] = coef(model)[1]
}

plot(df)
draw_derivatives(ddf, rg+2)

Is_min = rep(NA, nbr)
for (k in (rg+2):(nbr-rg-1)) {
  Is_min[k] = (ddf$dY[k-1] < 0) && (ddf$dY[k+1] > 0)
}
Is_min
sum(Is_min, na.rm=TRUE)

points(x = X[Is_min], y = rep(0, length(X[Is_min])), col = 'red', pch=17)
