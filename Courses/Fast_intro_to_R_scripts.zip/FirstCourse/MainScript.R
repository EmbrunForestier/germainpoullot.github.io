5+3

3+5

# ----------------------------------

c (2, 5, -2, 2, -1, 1, 3, 4, 5, 6, 7, 8, 9, 11, -2)

Temp = c (2, 5, -2, 2, -1)
Week = c("Monday", 'Tuedsday', 'Wednesday', 'Thursday', 'Friday', "Saturday", 'Sunday')

my_table = data.frame(Week, Temp) # Does not work...

Temp = c (2, 5, -2, 2, -1, 0, -1)

my_table = data.frame(Week, Temp) # Works !

View(my_table)

my_table$Temp

unique(my_table$Temp)
length(unique(my_table$Temp))

mean(my_table$Temp)
var(my_table$Temp)
sd(my_table$Temp)

my_table[1, 2]
my_table[2, 1]

my_table[3:4, 1:2]
my_table[c(1, 3), 2]

my_table[1, ]
my_table[5, ]
my_table[, 1]
my_table[, 2]

my_table$Week[3]
my_table$Week[1:4]

my_table[9]

# ----------------------------------

my_table$Temp < 0
my_table$Temp <= 0

which(my_table$Temp < 0)
my_table[my_table$Temp < 0, ]
subset(my_table, Temp < 0)

mean(my_table[my_table$Temp < 0, 2])
mean(my_table[my_table$Temp < 0, ]$Temp)
mean(subset(my_table, Temp < 0)$Temp)

# ----------------------------------

url = "https://gist.githubusercontent.com/MamathaReddygari/0b52821de0d7d92928c00e648f67f00c/raw/70e3c578bbf49755e99e2af528c20be11d47a3d5/fruits.csv"

retail = read.csv(url)
View(retail)

my_fruits = c ("Bananas", "Apples", "Pears", "Figs", "Blueberries")

my_groceries = subset(retail, Fruit %in% my_fruits)
View(my_groceries)

my_groceries = subset(my_groceries, !Form == "Frozen")

my_groceries = my_groceries[, c("Fruit", "Form", "RetailPrice")]

rownames(my_groceries) = NULL

my_groceries$Quantities = c(0.2, 0.5, 0.12, 0.15, 0.1)

my_groceries$PricePaid = my_groceries$RetailPrice * my_groceries$Quantities
sum(my_groceries$PricePaid)

# ---------------------------------

library(nycflights13)

?flights
?mean
example(sum)
View(flights)

c (nrow(flights), ncol(flights))

unique(flights$year)

length(unique(flights$dep_time))

flights$month == 3
sum(flights$month == 3)

month = c ("January", "Febuary", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December")
DELAYS = data.frame(month)
View(DELAYS)

for (i in c(1:12)) {
  print(i)
}

for (i in c(1:12)) {
  DELAYS$nbr_flights[i] = sum(flights$month == i)
}

c( sum(DELAYS$nbr_flights), nrow(flights) )

for (i in c(1:12)) {
  DELAYS$mean_delay[i] = mean(flights$dep_delay[flights$month == i])
  DELAYS$sd_delay[i] = sd(flights$dep_delay[flights$month == i])
}

flights$dep_delay[flights$month == 7]

mean(flights$dep_delay[flights$month == 7], na.rm=TRUE)

for (i in c(1:12)) {
  DELAYS$mean_delay[i] = mean(flights$dep_delay[flights$month == i], na.rm=TRUE)
  DELAYS$sd_delay[i] = sd(flights$dep_delay[flights$month == i], na.rm=TRUE)
}
