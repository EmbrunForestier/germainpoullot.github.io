?dunif
?punif
?qunif
?runif

x = (0:200) / 100
density = dunif(x)
distrib = punif(x)
quantile = qunif(x)

Unif = data.frame(x, density, distrib, quantile)
View(Unif) # It is weird to put quantile in this table...


library(tidyverse)
# If you do not have `tidyverse`, you can use `hist(...)` instead of `geom_histogram(...)`, and `curve(...)` instead of `stat_function(...)`, but it is annoying.

ggplot(data.frame(abscissa = c(-0.33,1.33)), aes(x = abscissa)) +
  stat_function(fun = dunif, linewidth = 0.5, color='blue') +
  stat_function(fun = punif, linewidth = 0.1, color='red') +
  labs(title = "Density  and distribution of Uniform(0,1)", y = "Density, Distribution") +
  ylim(0, 1.2) +
  theme_classic()


?dnorm
?pnorm
?qnorm
?rnorm

x = (-500:500) / 100 # old: x = (0:100) / 100
density = dnorm(x)
distrib = pnorm(x)
quantile = qnorm(x)

Norm = data.frame(x, density, distrib, quantile)
View(Norm) # here, it is clear that quantile is a bad idea!

ggplot(data.frame(x = c(-5,5)), aes(x = x)) +
  stat_function(fun = dnorm, linewidth = 0.5, color='blue') +
  stat_function(fun = pnorm, linewidth = 0.1, color='red') +
  labs(title = "Density and distribution of Normal(0,1)", y = "Density, Distribution") +
  ylim(0, 1.1) +
  theme_classic()


ggplot(data.frame(x = c(-0.1,1.1)), aes(x = x)) +
  stat_function(fun = qunif, color = 'cyan') +
  stat_function(fun = qnorm, color = 'orange') +
  ylim(-2.5, 2.5) +
  theme_classic()

# ---------------

# install.packages('plot.matrix')
# library(plot.matrix) # Useless

n = 50
A = matrix(rnorm(n^2), n, n)
View(A)
plot(A)
image(A)
image(A, col = heat.colors(100))
image(A, col = topo.colors(100))
image(A, col = colorRampPalette(c("white", "skyblue", "navy"))(100))

eigen(A)
View(eigen(A))

n = 100
A = matrix(rnorm(n^2), n, n)
W = (A + t(A)) / (2 * sqrt(2* n))

Ei = eigen(W)$values
max(Ei)
View(Ei)

ggplot(data.frame(ei = Ei), aes(x = ei)) +
  geom_histogram(binwidth = 0.05, fill = "lightblue", color='black')

hist(Ei, probability = TRUE)
?hist

# -----------------

test_range = data.frame(n = as.integer(1.5^(4:19)))
for (i in 1:16) {
  n = test_range$n[i]
  A = matrix(rnorm(n^2), n, n)
  W = A + t(A)
  test_range$max_ei[i] = max(eigen(W)$values)
}

View(test_range)

library(tidyverse)

ggplot(test_range, aes(x = n, y = max_ei)) +
  geom_line() +
  theme_classic()

ggplot(test_range, aes(x = n, y = max_ei)) +
  geom_line() +
  scale_x_log10() +
  scale_y_log10() +
  theme_classic()

# This seems to be a line of slope 1/2, let's try.

test_range = data.frame(n = as.integer(1.5^(4:19)))
for (i in 1:16) {
  n = test_range$n[i]
  A = matrix(rnorm(n^2), n, n)
  W = (A + t(A)) / (sqrt(n))
  test_range$max_ei[i] = max(eigen(W)$values)
}

ggplot(test_range, aes(x = n, y = max_ei)) +
  geom_line() +
  theme_classic()

ggplot(test_range, aes(x = n, y = max_ei)) +
  geom_line() +
  scale_x_log10() +
  scale_y_log10() +
  theme_classic()


# By convention, we use
# W = (A + t(A)) / (2 * sqrt(2 * n))

test_range = data.frame(n = as.integer(1.5^(4:19)))
for (i in 1:16) {
  n = test_range$n[i]
  A = matrix(rnorm(n^2), n, n)
  W = (A + t(A)) / (2 * sqrt(2 * n))
  test_range$max_ei[i] = max(eigen(W)$values)
}

ggplot(test_range, aes(x = n, y = max_ei)) +
  geom_line() +
  theme_classic()

# ---------------

dwigner <- function(x, radius = 1){
  y = numeric(length(x))
  inside = abs(x) <= radius
  y[inside] = (2 / pi*radius^2) * sqrt(radius^2 - x[inside]^2)
  return(y)
}


pwigner <- function(x, radius = 1){
  y = numeric(length(x))
  inside = abs(x) <= radius
  y[x <= -radius] = 0
  y[x >= radius] = 1
  z = x[inside] / radius
  y[inside] = 1/2 + (z*sqrt(1 - z^2) + asin(z))/pi
  y # return(...) is useless in R because it automatically returns the last computed value, here `y`
}


ggplot(data.frame(x = c(-1.2,1.2)), aes(x = x)) +
  stat_function(fun = dwigner, linewidth = 0.5, color='blue') +
  stat_function(fun = pwigner, linewidth = 0.1, color='red') +
  labs(title = "Density and distribution of Wigner(0,1)", y = "Density, Distribution") +
  ylim(0, 1.1) +
  theme_classic()

# ---------------

n = 500
A = matrix(rnorm(n^2), n, n)
W = (A + t(A)) / (2 * sqrt(2*n))
Ei = eigen(W)$values

ggplot(data.frame(ei = Ei), aes(x = ei)) +
  geom_histogram(aes(y =  after_stat(density)), fill = "lightblue", color='black') +
  stat_function(fun = dwigner, linewidth = 0.5, color='blue') +
  labs(title = "Density of Wigner(0,1) versus histogram of sample", y = "Density, Distribution") +
  xlim(-1.1, 1.1) + ylim(0, 1) +
  theme_classic()


# Let's verify that we are indeed converging towards the Wigner semi-circle distribution

mean(Ei) # 0   ?
var(Ei)  # 1/4 ?

test_convergence = data.frame(n = as.integer(1.5^(4:19)))
for (i in 1:16) {
  n = test_convergence$n[i]
  A = matrix(rnorm(n^2), n, n)
  W = ( A + t(A) ) / (2 * sqrt(2*n))
  Ei = eigen(W)$values
  test_convergence$mean[i] = mean(Ei)
  test_convergence$var[i] = var(Ei)
}
View(test_convergence)

ggplot(test_convergence, aes(x = n)) +
  geom_line(aes(y = mean, color = 'mean')) +
  geom_line(aes(y = var, color = 'variance')) +
  labs(title = "Convergence of mean and variance of eigenvalues", y = 'means and variances') +
  theme_classic()


?ks.test
ks.test(Ei, pwigner)
# D = sup_t |empirical_F(t) - true_F(t)|
# 1 - (p-value) : answer to "If Ei were truly distributed from dwigner, how surprised is this to observe my data?"
# "two-sided" means that R is testing whether the distribution of Ei is both above and below the one of pwigner.
# ks.test runs a Monte--Carlo method, it is not computing the exact D, but a very good approximation by sampling inside the domain of definition of dwigner.

KS = ks.test(Ei, pwigner)
View(KS)
D = KS$statistic
D

#test_convergence = data.frame(n = as.integer(1.5^(4:19)))
for (i in 1:16) {
  n = test_convergence$n[i]
  A = matrix(rnorm(n^2), n, n)
  W = ( A + t(A) ) / (2 * sqrt(2*n))
  Ei = eigen(W)$values
  test_convergence$D[i] = ks.test(Ei, pwigner)$statistic
}
View(test_convergence)

ggplot(test_convergence, aes(x = n, y = D)) +
  geom_line() +
  labs(title = "Convergence of the Kolmogorov distance") +
  theme_classic()

ggplot(test_convergence, aes(x = n, y = D)) +
  geom_line() +
  scale_x_log10() + scale_y_log10() + 
  labs(title = "Convergence of the Kolmogorov distance in log-log") +
  theme_classic()


# ---------------
# Covariance Matrix

# remove(list=ls())

XY = data.frame(x = runif(100), y = runif(100))
View(XY)

nrow(XY)

cov(XY)

source("what_is_my_shape.R")

# My shape is inside the box [-1.5, +3] x [-2, +2]
in_my_shape(4, 2)
in_my_shape(0, 0)

XY = data.frame(x = runif(10000, min = -1.5, max = 3), y = runif(10000, min = -2, max = 2))
nrow(XY)

ggplot(XY, aes(x = x, y = y)) +
  geom_point()

in_my_shape(XY)

mapply(in_my_shape, XY$x, XY$y)

MonteCarlo = XY[mapply(in_my_shape, XY$x, XY$y), ]
View(MonteCarlo)

nrow(MonteCarlo)
# What is the area of my shape, roughly?

ggplot(MonteCarlo, aes(x = x, y = y)) +
  geom_point()

Sigma = cov(MonteCarlo)
eigen(Sigma)

ei = eigen(Sigma)$values
P = eigen(Sigma)$vector

ggplot(MonteCarlo, aes(x = x, y = y)) +
  geom_point() +
  geom_segment(aes(x = -ei[1]*P[1, 1], y = -ei[1]*P[2, 1], xend = ei[1]*P[1, 1], yend = ei[1]*P[2, 1]),
               arrow = arrow(ends='both', length = unit(0.3, "cm")),
               color = "red", linewidth = 1.2) +
  geom_segment(aes(x = -ei[2]*P[1, 2], y = -ei[2]*P[2, 2], xend = ei[2]*P[1, 2], yend = ei[2]*P[2, 2]),
               arrow = arrow(ends='both', length = unit(0.3, "cm")),
               color = "blue", linewidth = 1.2) +
  theme_classic()


reveal_shape()


# You can also play with
#in_my_shape2(...)
#reveal_shape2(...)


# Independent Component Analysis (for getting the second direction)
#install.packages("ica")
library(ica)
?ica

fit = ica(MonteCarlo, nc = 2, method = "fast")
View(fit)

P = fit$M
vafs = fit$vafs

ggplot(MonteCarlo, aes(x = x, y = y)) +
  geom_point() +
  geom_segment(aes(x = -vafs[1]*P[1, 1], y = -vafs[1]*P[2, 1], xend = vafs[1]*P[1, 1], yend = vafs[1]*P[2, 1]),
               arrow = arrow(ends='both', length = unit(0.3, "cm")),
               color = "red", linewidth = 1.2) +
  geom_segment(aes(x = -vafs[2]*P[1, 2], y = -vafs[2]*P[2, 2], xend = vafs[2]*P[1, 2], yend = vafs[2]*P[2, 2]),
               arrow = arrow(ends='both', length = unit(0.3, "cm")),
               color = "blue", linewidth = 1.2) +
  theme_classic()


# ---------------
# Convergence in probability ?