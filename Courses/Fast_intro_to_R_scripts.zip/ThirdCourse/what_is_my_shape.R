in_my_shape <- function(x, y) {
  #x = xy[0]
  #y = xy[1]
  u1 <- c(1, 1) / sqrt(2)
  v1 <- c(-1, 1) / sqrt(2)
  a1 <- 2
  b1 <- 0.25
  
  p <- c(x, y)
  q <- c(x-1.5, y)
  
  e1 <- (sum(p * u1) / a1)^2 + (sum(p * v1) / b1)^2 <= 1
  e2 <- (sum(q * u1) / a1)^2 + (sum(q * v1) / b1)^2 <= 1
  
  return(e1 | e2)
}


reveal_shape <- function() {
  # Ellipse E1
  u1 <- c(1, 1) / sqrt(2)
  v1 <- c(-1, 1) / sqrt(2)
  a1 <- 2
  b1 <- 0.35
  
  # Membership function
  in_union <- function(x, y) {
    p <- c(x, y)
    q <- c(x-1.5, y)
    e1 <- (sum(p * u1) / a1)^2 + (sum(p * v1) / b1)^2 <= 1
    e2 <- (sum(q * u1) / a1)^2 + (sum(q * v1) / b1)^2 <= 1
    e1 | e2
  }
  
  # Grid
  grid_x <- seq(-1.5, 3, length.out = 300)
  grid_y <- seq(-2, 2, length.out = 300)
  Z <- outer(grid_x, grid_y, Vectorize(in_union))
  
  # Draw filled region
  image(grid_x, grid_y, Z,
        col = c("white", "lightblue"),
        xlab = "x", ylab = "y",
        asp = 1,
        main = "Filled Union of Two Ellipses")
}



in_my_shape2 <- function(x, y) {
  #x = xy[0]
  #y = xy[1]
  u1 <- c(1, 1) / sqrt(2)
  v1 <- c(-1, 1) / sqrt(2)
  a1 <- 2
  b1 <- 0.25
  
  u2 <- c(0, 1)
  v2 <- c(1, 0)
  a2 <- 0.66
  b2 <- 0.66
  
  p <- c(x, y)
  
  e1 <- (sum(p * u1) / a1)^2 + (sum(p * v1) / b1)^2 <= 1
  e2 <- (sum(p * u2) / a2)^2 + (sum(p * v2) / b2)^2 <= 1
  
  return(e1 | e2)
}


reveal_shape2 <- function() {
  # Ellipse E1
  u1 <- c(1, 1) / sqrt(2)
  v1 <- c(-1, 1) / sqrt(2)
  a1 <- 2
  b1 <- 0.35
  
  # Ellipse E2
  u2 <- c(0, 1)
  v2 <- c(1, 0)
  a2 <- 0.66
  b2 <- 0.66
  
  # Membership function
  in_union <- function(x, y) {
    p <- c(x, y)
    e1 <- (sum(p * u1) / a1)^2 + (sum(p * v1) / b1)^2 <= 1
    e2 <- (sum(p * u2) / a2)^2 + (sum(p * v2) / b2)^2 <= 1
    e1 | e2
  }
  
  # Grid
  grid_x <- seq(-2.5, 2.5, length.out = 300)
  grid_y <- seq(-2.5, 2.5, length.out = 300)
  Z <- outer(grid_x, grid_y, Vectorize(in_union))
  
  # Draw filled region
  image(grid_x, grid_y, Z,
        col = c("white", "lightblue"),
        xlab = "x", ylab = "y",
        asp = 1,
        main = "Filled Union of Two Ellipses")
}