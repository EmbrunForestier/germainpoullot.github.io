library(tidyverse)

hurricanes = read.csv("hurricanes.csv")

View(hurricanes)

hurricanes |>
  group_by(year) |>
  slice_head()

hurricanes |>
  group_by(year) |>
  slice_min(order_by = pressure) |>
  filter(year >= 1980 & year <= 2000)

hurricanes |>
  group_by(year) |>
  summarise(n())

hurricanes |>
  group_by(year) |>
  summarise(number_of_hurricanes = n())

hurricanes |>
  group_by(year) |>
  summarise(mean = mean(wind), numb = n())


# ---------------


students = read.csv("students.csv", sep=",")
View(students)

students = pivot_wider(students,
            id_cols = name,
            names_from = attribute,
            values_from = value
            )

?pivot_wider
example(pivot_wider)

students |>
  group_by(major) |>
  summarize(GPA = mean(GPA)) # Does not work

students$GPA = as.numeric(students$GPA)

students

students |>
  group_by(major) |>
  summarize(GPA = mean(GPA))

?pivot_longer

# ---------------

best = read.csv("favorite_subjects.csv")
View(best)

best |>
  group_by(Subject) |>
  summarize(votes = n()) |>
  arrange(desc(votes))

best$Subject = best$Subject |>
  str_trim() |>
  str_squish() |>
  str_to_title()

# ---------------

German = c("Statistik", 'Mathematik', 'Informatik')
English = c('Statistics', 'Mathematics', 'Computer Science')

for (i in 1:3) {
  best$Subject[best$Subject == German[i]] = English[i]
}

best$Subject == German[1]
best$Subject[best$Subject == German[1]]

any(best$Subject %in% German)
all(best$Subject %in% English)

poll = best |>
  group_by(Subject) |>
  summarize(votes = n()) |>
  ungroup() |>
  arrange(desc(votes))

View(poll)

# How many for Math + Stats + Algebra ?
# How many for Computer Science + Data Science ?

# ---------------

ggplot(poll)

ggplot(poll, aes(x = Subject, y = votes)) +
  geom_col()

ggplot(poll, aes(y = Subject, x = votes)) +
  geom_col()

ggplot(poll, aes(x = Subject, y = votes)) +
  geom_col() +
  coord_flip()

ggplot(poll, aes(x = reorder(Subject, votes, decreasing = TRUE), y = votes)) +
  geom_col() +
  labs(x = "Subject", y = "nb votes", title = "Favorite subjects")

ggplot(poll, aes(x = Subject, y = votes)) +
  geom_col() +
  scale_y_continuous(limits = c(0, 40))

ggplot(poll, aes(x = reorder(Subject, votes, decreasing = TRUE), y = votes)) +
  geom_col(aes(fill = Subject))
  labs(x = "Subject", y = "nb votes", title = "Favorite subjects")

ggplot(poll, aes(x = reorder(Subject, votes, decreasing = TRUE), y = votes)) +
  geom_col(aes(fill = Subject)) +
  scale_fill_viridis_d("Theme") +
  labs(x = "Subject", y = "nb votes", title = "Favorite subjects")

ggplot(poll, aes(x = reorder(Subject, votes, decreasing = TRUE), y = votes)) +
  geom_col(aes(fill = Subject), show.legend = FALSE) +
  scale_fill_viridis_d("Theme") +
  labs(x = "Subject", y = "nb votes", title = "Favorite subjects") +
  theme_classic()

p = ggplot(poll, aes(x = reorder(Subject, votes, decreasing = TRUE), y = votes)) +
  geom_col(aes(fill = Subject), show.legend = FALSE) +
  scale_fill_viridis_d("Theme") +
  labs(x = "Subject", y = "nb votes", title = "Favorite subjects") +
  theme_classic()
p

ggsave("FavoriteSubject.png", plot = p, height = 900, width = 2400, units = "px")

# ---------------

ggplot(hurricanes, aes(x = pressure, y = wind)) +
  geom_point(shape = 1, aes(color = year)) +
  labs(title = "Hurricanes") +
  theme_classic()

ggplot(hurricanes, aes(x = pressure, y = wind)) +
  geom_jitter(aes(color = year)) +
  labs(title = "Hurricanes") +
  theme_classic()

SaffirSimpson = c(64, 83, 96, 113, 137)
hurricanes$category = findInterval(hurricanes$wind, SaffirSimpson)

?findInterval

p = ggplot(hurricanes, aes(x = pressure, y = wind, color = factor(category))) +
  geom_point(shape = 1, show.legend = FALSE) +
  labs(title = "Hurricanes") +
  theme_classic()
p

my_colors = c('green', 'orange', 'red', 'purple', 'black')

p = ggplot(hurricanes, aes(x = pressure, y = wind, color = factor(category))) +
  geom_point(shape = 1, show.legend = FALSE) +
  scale_color_manual(values = my_colors) +
  labs(title = "Hurricanes") +
  theme_classic()
p

for (i in 1:6) {
  p = p + geom_hline(linetype = 3, yintercept = SaffirSimpson[i]+0.5, color=my_colors[i])
}
p

# ---------------

p + geom_smooth(method = "lm", se = FALSE, show.legend = FALSE)
p + geom_smooth(method = "lm", se = TRUE, show.legend = FALSE)

model <- lm(wind ~ pressure, data = hurricanes)
summary(model)

model$coefficients[1]
model$coefficients[2]

r2 <- summary(model)$r.squared
r2

q = ggplot(hurricanes, aes(x = pressure, y = wind)) +
  geom_point(shape = 1, show.legend=FALSE) +
  labs(title = "Hurricanes") +
  theme_classic()
for (i in 1:6) {
  q = q + geom_hline(linetype = 3, yintercept = SaffirSimpson[i]+0.5, color=my_colors[i])
}

q + geom_smooth(method = "lm", se = TRUE, show.legend = FALSE) +
  annotate("text",
         x = Inf, y = Inf,
         label = paste0("R² = ", round(r2, 3)),
         hjust = 1.1, vjust = 1.5)

