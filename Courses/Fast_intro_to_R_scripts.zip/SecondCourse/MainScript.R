# install.packages("tidyverse")

library(tidyverse)

storms

View(storms)

# ---------------

?select
?dplyr::select

select(storms,
       -c(lat, long)
       )

select(storms,
       -c(lat, long, ends_with("diameter"))
)

filter(storms,
       status == "hurricane")

# ---------------

hurricanes = storms |>
  select(-c(lat, long, ends_with("diameter"))) |>
  filter(status == "hurricane")

View(hurricanes)

length(unique(hurricanes$name))
mean(hurricanes$pressure)

# ---------------

arrange(hurricanes, wind)
arrange(hurricanes, desc(wind))
arrange(hurricanes, desc(wind), name)

arrange(hurricanes, desc(wind), name) |>
  distinct(name, year)

# ---------------

clean_hurricanes = arrange(hurricanes, desc(wind), name) |>
  distinct(name, year, .keep_all = TRUE)

clean_hurricanes |>
  select(c(year, name, wind, pressure)) |>
  write.csv("hurricanes.csv", row.names = FALSE)
